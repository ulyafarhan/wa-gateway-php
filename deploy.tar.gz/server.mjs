// ponytail: WhatsApp Gateway v5 — multi-tenant, priority queue, server-side auth
import 'dotenv/config';
import express from 'express';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import cors from 'cors';
import pino from 'pino';
import path from 'path';
import { fileURLToPath } from 'url';
import db from './src/db.js';
import router from './src/routes.js';
import adminRouter from './src/routes-admin.js';
import { connectSession, getSessionStatus } from './src/session.js';
import { startWebhookProcessor } from './src/webhook.js';
import { startBroadcastProcessor } from './src/broadcast.js';
import { startSyncEngine, initD1Schema, syncHealthCheck } from './src/sync.js';
import { createUser, getUserByUsername, verifyToken, getUserById } from './src/auth.js';
import QRCode from 'qrcode';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = parseInt(process.env.PORT || '2785', 10);
const logger = pino({ level: process.env.LOG_LEVEL || 'silent' });

// Seed admin user
if (process.env.SEED_ADMIN_USER && process.env.SEED_ADMIN_PASS) {
    if (!getUserByUsername(process.env.SEED_ADMIN_USER)) {
        createUser({
            username: process.env.SEED_ADMIN_USER,
            email: process.env.SEED_ADMIN_EMAIL || 'admin@wagateway.local',
            password: process.env.SEED_ADMIN_PASS,
            role: 'superadmin'
        });
        logger.info(`Seed admin user created: ${process.env.SEED_ADMIN_USER}`);
    }
}

// EJS + middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(cookieParser());
app.use(express.json());
app.use('/assets', express.static(path.join(__dirname, 'public', 'assets')));
app.use('/assets/images', express.static(path.join(__dirname, 'frontend', 'public', 'images')));

// ponytail: CORS — whitelist production + dev
const ALLOWED_ORIGINS = (process.env.CORS_ORIGINS || 'https://wa.gampong.web.id,http://localhost:2785').split(',');
app.use(cors({ origin: ALLOWED_ORIGINS, credentials: true }));

// ponytail: security headers via helmet + manual overrides
app.use(helmet({
    contentSecurityPolicy: false,
    hsts: { maxAge: 31536000, includeSubDomains: true },
}));
app.use((_req, res, next) => {
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    next();
});

// ponytail: server-side auth — check JWT cookie, redirect if missing
function requireAuth(req, res, next) {
    const token = req.cookies?.token;
    if (!token) return res.redirect('/login');
    const decoded = verifyToken(token);
    if (!decoded) return res.clearCookie('token').redirect('/login');
    req.user = decoded;
    next();
}

// ponytail: SSR helpers — fetch data server-side, zero client flash
function getStats(userId, role) {
    let sessions;
    if (role === 'superadmin' || role === 'admin') {
        sessions = db.prepare('SELECT * FROM sessions').all();
    } else {
        sessions = db.prepare(`
            SELECT s.* FROM sessions s
            LEFT JOIN user_sessions us ON s.session_id = us.session_id
            WHERE us.user_id = ? OR us.user_id IS NULL
        `).all(userId);
    }
    const total = sessions.length;
    const online = sessions.filter(s => s.status === 'connected').length;
    const messages = sessions.reduce((s, x) => s + (x.msg_sent || 0) + (x.msg_failed || 0), 0);
    const contacts = sessions.reduce((s, x) => {
        const c = db.prepare('SELECT COUNT(*) as c FROM user_profiles WHERE session_id = ?').get(x.session_id);
        return s + (c?.c || 0);
    }, 0);
    const webhooks = sessions.reduce((s, x) => {
        const c = db.prepare("SELECT COUNT(*) as c FROM webhook_outbox WHERE session_id = ? AND status='pending'").get(x.session_id);
        return s + (c?.c || 0);
    }, 0);
    const tenants = db.prepare('SELECT COUNT(*) as c FROM tenants').get().c;
    return { totalSessions: total, onlineSessions: online, totalMessages: messages, totalContacts: contacts, pendingWebhooks: webhooks, totalTenants: tenants };
}

function getSessionList(userId, role) {
    if (role === 'superadmin' || role === 'admin') {
        return db.prepare('SELECT session_id, status, tenant_id, session_type, msg_sent, msg_failed, created_at FROM sessions ORDER BY created_at DESC').all();
    }
    return db.prepare('SELECT session_id, status, msg_sent, msg_failed, created_at FROM sessions ORDER BY created_at DESC').all();
}

// Login page (no auth needed)
app.get('/login', (req, res) => {
    const token = req.cookies?.token;
    if (token && verifyToken(token)) return res.redirect('/');
    res.render('login', { page: 'login' });
});

// Dashboard — render stats server-side
app.get('/', requireAuth, (req, res) => {
    const stats = getStats(req.user.id, req.user.role);
    const sessions = getSessionList(req.user.id, req.user.role);
    const user = getUserById(req.user.id);
    const tenants = (req.user.role === 'superadmin' || req.user.role === 'admin')
        ? db.prepare('SELECT * FROM tenants ORDER BY created_at DESC').all()
        : [];
    res.render('dashboard', { page: 'dashboard', stats, sessions, user, tenants });
});

// Sessions list
app.get('/sessions', requireAuth, (req, res) => {
    const sessions = getSessionList(req.user.id, req.user.role);
    const user = getUserById(req.user.id);
    const tenants = (req.user.role === 'superadmin' || req.user.role === 'admin')
        ? db.prepare('SELECT * FROM tenants ORDER BY created_at DESC').all()
        : [];
    res.render('sessions', { page: 'sessions', sessions, user, tenants });
});

// Session detail — pass session data for server-side QR render
app.get('/sessions/:id', requireAuth, async (req, res) => {
    const user = getUserById(req.user.id);
    const dbSession = db.prepare('SELECT session_id, tenant_id, session_type, msg_sent, msg_failed, created_at FROM sessions WHERE session_id = ?').get(req.params.id);
    const live = getSessionStatus(req.params.id);
    const session = { ...dbSession, status: live.status, qr: live.qr };
    let qrDataUrl = null;
    if (live.qr && live.status === 'waiting_qr') {
        try { qrDataUrl = await QRCode.toDataURL(live.qr, { width: 280, margin: 2 }); } catch {}
    }
    res.render('session', { page: 'session', sessionId: req.params.id, user, session, qrDataUrl });
});

// Messages
app.get('/messages', requireAuth, (req, res) => {
    const user = getUserById(req.user.id);
    res.render('messages', { page: 'messages', user });
});

// Contacts
app.get('/contacts', requireAuth, (req, res) => {
    const user = getUserById(req.user.id);
    res.render('contacts', { page: 'contacts', user });
});

// Behavior
app.get('/behavior', requireAuth, (req, res) => {
    const user = getUserById(req.user.id);
    res.render('behavior', { page: 'behavior', user });
});

// Webhooks
app.get('/webhooks', requireAuth, (req, res) => {
    const user = getUserById(req.user.id);
    res.render('webhooks', { page: 'webhooks', user });
});

// API Keys
app.get('/api-keys', requireAuth, (req, res) => {
    const user = getUserById(req.user.id);
    res.render('api-keys', { page: 'api-keys', user });
});

// Settings
app.get('/settings', requireAuth, (req, res) => {
    const user = getUserById(req.user.id);
    res.render('settings', { page: 'settings', user });
});

// Users (superadmin)
app.get('/users', requireAuth, (req, res) => {
    const user = getUserById(req.user.id);
    res.render('users', { page: 'users', user });
});

// Tenants (superadmin)
app.get('/tenants', requireAuth, (req, res) => {
    const user = getUserById(req.user.id);
    if (user?.role !== 'superadmin' && user?.role !== 'admin') return res.redirect('/');
    const tenants = db.prepare('SELECT * FROM tenants ORDER BY created_at DESC').all();
    res.render('tenants', { page: 'tenants', user, tenants });
});

// ponytail: bridge cookie → Authorization header for API routes
// SSR pages use httpOnly cookie; client JS uses localStorage.getItem('token') (always null)
// This ensures API routes work with cookie auth — fixes 26 fetch() calls across all EJS views
app.use('/api', (req, res, next) => {
    if (req.cookies?.token) {
        req.headers.authorization = 'Bearer ' + req.cookies.token;
    }
    next();
});

// API routes
app.use(adminRouter);
app.use(router);

// Start
startWebhookProcessor();
startBroadcastProcessor();

// ponytail: Initialize sync engine (SQLite → Supabase + D1)
async function initServices() {
    // Init D1 schema (creates tables if not exist)
    const d1Result = await initD1Schema();
    if (d1Result.success) {
        logger.info('D1 schema initialized');
    } else {
        logger.warn(`D1 schema init failed: ${d1Result.error} (D1 sync disabled)`);
    }
    
    // Start sync engine
    startSyncEngine();
    logger.info('Sync engine started');
    
    // Check sync health
    const health = await syncHealthCheck();
    logger.info('Sync health:', JSON.stringify(health));
}

initServices().catch(e => logger.error(`Init services error: ${e.message}`));

app.listen(PORT, process.env.HOST || '0.0.0.0', () => {
    logger.info(`WhatsApp Gateway v5 running on http://localhost:${PORT}`);
    const existing = db.prepare('SELECT session_id FROM sessions').all();
    for (const { session_id } of existing) {
        connectSession(session_id).catch(e => logger.error(`[${session_id}] ${e.message}`));
    }
});

process.on('SIGTERM', () => { logger.info('Shutting down...'); process.exit(0); });
process.on('SIGINT', () => { logger.info('Shutting down...'); process.exit(0); });
